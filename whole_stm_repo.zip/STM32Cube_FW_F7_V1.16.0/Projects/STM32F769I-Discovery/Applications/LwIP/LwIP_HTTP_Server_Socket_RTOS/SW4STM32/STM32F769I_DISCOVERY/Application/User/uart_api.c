
#include "uart_api.h"
#include "main.h"
#include <string.h>


static void MX_USART1_UART_Init(void);

static UART_HandleTypeDef huart1;
static volatile int8_t buffer[RX_BUFFER_SIZE];
static volatile int32_t buffer_cnt;
static volatile uint8_t recv_data;
static volatile bool recv_command;


void UartInit(void){
	MX_USART1_UART_Init();
	buffer_cnt = 0;
	recv_command = false;

	HAL_NVIC_SetPriority(USART1_IRQn, 5, 0);
	HAL_NVIC_EnableIRQ(USART1_IRQn);

	HAL_UART_Receive_IT(&huart1, &recv_data, 1);
}

void UartWriteCommand(int8_t *data, int32_t size){
	 HAL_UART_Transmit(&huart1, (uint8_t *)data, size, 100);
}

int32_t UartReadCommand(int8_t *data, int32_t max_size){
	int32_t size = 0;
	if(data && max_size > 0 && recv_command){
		size = buffer_cnt;
		if (size > max_size)
			size = max_size;

		memcpy(&data[0], &buffer[0], size);

		buffer_cnt -= size;
		recv_command = false;
	}
	return size;
}

int32_t UartReadData(int8_t *data, int32_t max_size){
	int32_t size = 0;
	if(data && max_size > 0){
		size = buffer_cnt;
		if (size > max_size)
			size = max_size;

		memcpy(&data[0], &buffer[0], size);

		buffer_cnt -= size;
	}
	return size;
}

static void MX_USART1_UART_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;


  __HAL_RCC_USART1_CLK_ENABLE();

  __HAL_RCC_GPIOA_CLK_ENABLE();
  /**USART1 GPIO Configuration
  PA10     ------> USART1_RX
  PA9     ------> USART1_TX
  */
  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
	  while(1){}
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if (buffer_cnt < RX_BUFFER_SIZE)
	{
		int8_t data = recv_data;
		buffer[buffer_cnt++] = recv_data;
		if (data == '\r')
		{
			recv_command = true;
		}
	}

	HAL_UART_Transmit_IT(&huart1, &recv_data, 1);
	HAL_UART_Receive_IT(&huart1, &recv_data, 1);
}

void USART1_IRQHandler(void)
{
  HAL_UART_IRQHandler(&huart1);
}


/**
* @brief UART MSP Initialization
* This function configures the hardware resources used in this example
* @param huart: UART handle pointer
* @retval None
*/
void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(huart->Instance==USART1)
  {
    /* Peripheral clock enable */
    __HAL_RCC_USART1_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART1 GPIO Configuration
    PA10     ------> USART1_RX
    PA9     ------> USART1_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USART1 interrupt Init */
    HAL_NVIC_SetPriority(USART1_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
  }
}

/**
* @brief UART MSP De-Initialization
* This function freeze the hardware resources used in this example
* @param huart: UART handle pointer
* @retval None
*/
void HAL_UART_MspDeInit(UART_HandleTypeDef* huart)
{
  if(huart->Instance==USART1)
  {
    /* Peripheral clock disable */
    __HAL_RCC_USART1_CLK_DISABLE();

    /**USART1 GPIO Configuration
    PA10     ------> USART1_RX
    PA9     ------> USART1_TX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_10|GPIO_PIN_9);

    /* USART1 interrupt DeInit */
    HAL_NVIC_DisableIRQ(USART1_IRQn);
  }

}



