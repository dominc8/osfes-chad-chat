#ifndef UART_API_H
#define UART_API_H

#include <stdbool.h>
#include <stdint.h>

#define RX_BUFFER_SIZE	128

void USART1_IRQHandler(void);
void UartInit(void);
void UartWriteCommand(int8_t *data, int32_t size);
int32_t UartReadData(int8_t *data, int32_t max_size);
int32_t UartReadCommand(int8_t *data, int32_t max_size);

#endif
