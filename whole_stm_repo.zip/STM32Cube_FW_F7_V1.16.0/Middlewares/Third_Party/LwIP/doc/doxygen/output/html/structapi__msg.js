var structapi__msg =
[
    [ "ad", "structapi__msg.html#a36dedcbd9ecca67043a8e1d1e715be94", null ],
    [ "b", "structapi__msg.html#ab0abd60527e96cc24c2c20c835cdac05", null ],
    [ "bc", "structapi__msg.html#a1705127c6cd22c2c6dbbcc59834e41e0", null ],
    [ "conn", "structapi__msg.html#abec5e33802d69f1b601543d60699f028", null ],
    [ "err", "structapi__msg.html#a8c66bd95217fa627f13f2f0847bbb25f", null ],
    [ "jl", "structapi__msg.html#a6387bddb309c218ac0ccc5ef6d7a033e", null ],
    [ "len", "structapi__msg.html#a40624c398d1939bfee54bffa708a363e", null ],
    [ "msg", "structapi__msg.html#aef71459b5251d796434f741ca630d528", null ],
    [ "n", "structapi__msg.html#adbbfc2baa8088b31fc722365237e5807", null ],
    [ "offset", "structapi__msg.html#a4bd9382dd42b18120803e246a0203353", null ],
    [ "r", "structapi__msg.html#aebd72e07e711e7135294563b82c98cdf", null ],
    [ "sd", "structapi__msg.html#ad5e8bf133bc5ba4c78822af297330ce4", null ],
    [ "vector", "structapi__msg.html#a1ceb9822ba49ba439e30d98492593612", null ],
    [ "vector_cnt", "structapi__msg.html#ab6f14157a3e6735b69a569249d3286a2", null ],
    [ "vector_off", "structapi__msg.html#a6896ae78ebddefdf2d8358ab5f21f444", null ],
    [ "w", "structapi__msg.html#a8a71456d1199d10af5c1d8760cc0ce73", null ]
];