var structnetif__ext__callback__args__t_1_1ipv6__addr__state__changed__s =
[
    [ "addr_index", "structnetif__ext__callback__args__t_1_1ipv6__addr__state__changed__s.html#aebf2aa0b26b07ca1977c676a0404323f", null ],
    [ "address", "structnetif__ext__callback__args__t_1_1ipv6__addr__state__changed__s.html#acd24c243c866f8f9169b89af11974f17", null ],
    [ "old_state", "structnetif__ext__callback__args__t_1_1ipv6__addr__state__changed__s.html#a9b58712e82a73803391523324e19a776", null ]
];