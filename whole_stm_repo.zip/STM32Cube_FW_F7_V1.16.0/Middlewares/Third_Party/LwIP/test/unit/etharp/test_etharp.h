#ifndef LWIP_HDR_TEST_ETHARP_H
#define LWIP_HDR_TEST_ETHARP_H

#include "../lwip_check.h"

Suite* etharp_suite(void);

#endif
